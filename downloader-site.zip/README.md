# QuickDL — Video Downloader Website

Apni khud ki downloader site (savefrom.net jaisi). Link paste karo → quality chuno → MP4 download.

## Apne computer par chalana (testing)

```bash
cd downloader-site
pip install -r requirements.txt
# ffmpeg bhi install hona chahiye:  sudo apt install ffmpeg
python app.py
```

Phir browser mein kholo: **http://localhost:5000**

## Internet par live karna (hosting)

Sab se asaan tareeqa — **Render.com** (free):

1. Is folder ko GitHub par upload karo (naya repository banao).
2. [render.com](https://render.com) par account banao → "New Web Service" → GitHub repo connect karo.
3. Settings:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app` (pehle `pip install gunicorn` karke requirements mein add kar lo)
   - Free plan select karo.
4. Deploy dabao — kuch minute mein tumhari site live hogi, jaise `https://quickdl.onrender.com`.

> Note: free plan par site 15 minute idle rehne ke baad "so" jati hai, pehla visit thoda slow hoga.

Dusre options: **Railway.app**, **PythonAnywhere**, ya apna **VPS** (DigitalOcean/Hetzner).

## Zaroori baatein (honest notes)

- **YouTube blocking:** YouTube downloader servers ko block karta hai (bot verification). Agar YouTube downloads kaam na karein to ye YouTube ki taraf se hai — Facebook, TikTok, Instagram aksar chalte rehte hain. Residential IP ya cookies se behtar result milta hai.
- **ffmpeg** zaroori hai taake video+audio merge ho sakein (most hosts par pehle se hota hai, warna apt se install karo).
- **Qanoon/ToS:** Sirf apni ya ijazat wali videos download karo. YouTube ki Terms of Service downloading mana karti hain.
- **Kharcha:** Bari videos = zyada bandwidth. Free hosting par heavy use par limit lag sakti hai.

## Files

| File | Kaam |
|---|---|
| `app.py` | Flask backend — `/api/info` (video details) aur `/api/download` (MP4 download) |
| `templates/index.html` | Poora frontend (design + JavaScript) |
| `requirements.txt` | Python packages |
| `downloads/` | Downloaded files yahan save hote hain (auto banti hai) |
