"""
Simple video downloader website (like savefrom.net).
Paste a video URL -> see title/thumbnail -> pick quality -> download MP4.

Run:  pip install -r requirements.txt
      python app.py
Then open http://localhost:5000
"""
import json
import os
import re
import subprocess
import uuid
from flask import Flask, jsonify, render_template, request, send_file

app = Flask(__name__)

DL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "downloads")
os.makedirs(DL_DIR, exist_ok=True)

URL_RE = re.compile(r"^https?://", re.IGNORECASE)


def run_ytdlp(args, timeout=90):
    r = subprocess.run(
        ["yt-dlp"] + args,
        capture_output=True, text=True, timeout=timeout,
    )
    if r.returncode != 0:
        raise RuntimeError((r.stderr or "yt-dlp failed")[-300:])
    return r.stdout


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/info", methods=["POST"])
def api_info():
    url = (request.json or {}).get("url", "").strip()
    if not URL_RE.match(url):
        return jsonify({"ok": False, "error": "Please paste a valid http(s) video URL."})
    try:
        raw = run_ytdlp(["--no-playlist", "--dump-single-json",
                         "--no-warnings", "--socket-timeout", "20", url])
        d = json.loads(raw)
    except Exception as e:
        return jsonify({"ok": False,
                        "error": "Could not read this video. The site may block downloads."})

    quals = set()
    for f in d.get("formats") or []:
        h = f.get("height")
        if h and f.get("vcodec") != "none":
            quals.add(h)
    quals = sorted(q for q in quals if q <= 1080)
    if not quals:
        quals = [360]

    dur = d.get("duration") or 0
    mins, secs = divmod(int(dur), 60)
    return jsonify({
        "ok": True,
        "title": d.get("title") or "Video",
        "uploader": d.get("uploader") or d.get("channel") or "",
        "duration": f"{mins}:{secs:02d}" if dur else "",
        "thumbnail": d.get("thumbnail") or "",
        "qualities": quals,
    })


@app.route("/api/download", methods=["POST"])
def api_download():
    data = request.json or {}
    url = data.get("url", "").strip()
    try:
        q = int(data.get("quality", 720))
    except (TypeError, ValueError):
        q = 720
    if not URL_RE.match(url):
        return jsonify({"ok": False, "error": "Invalid URL."})

    fid = uuid.uuid4().hex
    out = os.path.join(DL_DIR, fid + ".mp4")
    fmt = f"bv*[height<={q}]+ba/b[height<={q}]/b"
    try:
        run_ytdlp(["--no-playlist", "-f", fmt, "--merge-output-format", "mp4",
                   "--no-warnings", "-o", out, url], timeout=900)
    except Exception as e:
        return jsonify({"ok": False, "error": f"Download failed: {e}"}), 502
    if not os.path.exists(out):
        return jsonify({"ok": False, "error": "Download failed (no file)."}), 502
    return send_file(out, as_attachment=True, download_name="video.mp4",
                     mimetype="video/mp4")


@app.route("/health")
def health():
    return jsonify({"ok": True})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
